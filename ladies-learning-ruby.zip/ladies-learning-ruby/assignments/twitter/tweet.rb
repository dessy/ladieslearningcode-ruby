class Tweet
  
  attr_accessor :message, :user_handle
  
end