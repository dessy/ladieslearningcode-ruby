puts "Okay, on the count of 5 ..."
[1, 2, 3, 4, 5].each do |i|
  puts i
  sleep 1
end
puts "GO!"