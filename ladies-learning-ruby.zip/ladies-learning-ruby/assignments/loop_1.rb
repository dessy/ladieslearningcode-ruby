puts "Hi!"
greeting = gets.chomp

while greeting != "bye!"
  puts greeting
  greeting = gets.chomp
end