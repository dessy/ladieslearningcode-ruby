tweet = "I'm writing my first program at the @llcodedotcom Intro to Ruby workshop!"
tweet.length