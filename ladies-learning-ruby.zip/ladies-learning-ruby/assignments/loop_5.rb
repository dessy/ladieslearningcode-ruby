puts "And the lucky numbers are ..."
[7,	13,	14,	16,	14,	48].each do |i|
  puts i
  sleep 1
end
puts "With a bonus number 32!"