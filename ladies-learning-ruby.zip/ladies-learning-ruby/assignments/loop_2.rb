3.times do
  puts "Hip-Hop-Hooray!"
  sleep 1
end