lisa = "Lisa Simpson"

puts lisa.length

bart = "Bart" + "Simpson"

puts bart

puts lisa + bart

puts lisa + bart.reverse

puts lisa.upcase

puts lisa

lisa = lisa.upcase

puts lisa

cartoon = lisa

puts cartoon

cartoon = bart

puts cartoon

bart = lisa

puts cartoon

puts bart